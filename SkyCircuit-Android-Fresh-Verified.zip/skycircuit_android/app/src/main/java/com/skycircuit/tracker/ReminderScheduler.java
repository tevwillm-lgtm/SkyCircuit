package com.skycircuit.tracker;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import java.util.Calendar;

/** Schedules inexact (Android-managed) training-day alarms without exact-alarm privilege. */
public final class ReminderScheduler {
    private static final String PREFS = "skycircuit_reminders";
    private static final int[] DAYS_3 = { Calendar.MONDAY, Calendar.WEDNESDAY, Calendar.FRIDAY };
    private static final int[] DAYS_4 = { Calendar.MONDAY, Calendar.TUESDAY, Calendar.THURSDAY, Calendar.SATURDAY };
    private static final int[] DAYS_5 = { Calendar.MONDAY, Calendar.TUESDAY, Calendar.THURSDAY, Calendar.FRIDAY, Calendar.SATURDAY };

    private ReminderScheduler() {}

    public static void configure(Context context, boolean enabled, int frequency, String time) {
        if (frequency < 3 || frequency > 5) frequency = 3;
        if (time == null || !time.matches("([01]\\d|2[0-3]):[0-5]\\d")) time = "07:00";
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean("enabled", enabled).putInt("frequency", frequency)
            .putString("time", time).apply();
        scheduleAll(context);
    }

    public static void scheduleAll(Context context) {
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        AlarmManager alarms = (AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        if (alarms == null) return;
        for (int day = Calendar.SUNDAY; day <= Calendar.SATURDAY; day++) {
            PendingIntent old = pending(context, day);
            alarms.cancel(old);
            old.cancel();
        }
        if (!p.getBoolean("enabled", false)) return;
        int frequency = p.getInt("frequency", 3);
        for (int day : days(frequency)) scheduleDay(context, day);
    }

    public static void scheduleDay(Context context, int day) {
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (!p.getBoolean("enabled", false) || !isTrainingDay(p.getInt("frequency", 3), day)) return;
        String time = p.getString("time", "07:00");
        String[] parts = time.split(":");
        Calendar current = Calendar.getInstance();
        Calendar target = Calendar.getInstance();
        target.set(Calendar.DAY_OF_WEEK, day);
        target.set(Calendar.HOUR_OF_DAY, Integer.parseInt(parts[0]));
        target.set(Calendar.MINUTE, Integer.parseInt(parts[1]));
        target.set(Calendar.SECOND, 0);
        target.set(Calendar.MILLISECOND, 0);
        if (!target.after(current)) target.add(Calendar.DAY_OF_YEAR, 7);
        AlarmManager manager = (AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        if (manager != null) manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, target.getTimeInMillis(), pending(context, day));
    }

    private static boolean isTrainingDay(int frequency, int day) {
        for (int d : days(frequency)) if (day == d) return true;
        return false;
    }

    private static int[] days(int frequency) { return frequency == 5 ? DAYS_5 : frequency == 4 ? DAYS_4 : DAYS_3; }

    private static PendingIntent pending(Context context, int day) {
        Intent intent = new Intent(context, ReminderReceiver.class);
        intent.putExtra("day", day);
        return PendingIntent.getBroadcast(context, 1000 + day, intent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
