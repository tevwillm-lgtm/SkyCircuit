package com.skycircuit.tracker;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import java.util.UUID;
import java.util.ArrayList;
import java.util.HashSet;

/** Reads the standard BLE Heart Rate Measurement characteristic from a Polar H10. */
public final class HeartRateMonitor {
    public interface Listener { void update(int bpm, String status); }
    private static final UUID HEART_SERVICE = UUID.fromString("0000180d-0000-1000-8000-00805f9b34fb");
    private static final UUID HEART_MEASUREMENT = UUID.fromString("00002a37-0000-1000-8000-00805f9b34fb");
    private static final UUID NOTIFY_DESCRIPTOR = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    private final Activity activity;
    private final Listener listener;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private boolean scanning;
    private final ArrayList<BluetoothDevice> candidates = new ArrayList<>();
    private final ArrayList<String> candidatesLabels = new ArrayList<>();
    private final HashSet<String> seen = new HashSet<>();

    public HeartRateMonitor(Activity activity, Listener listener) {
        this.activity = activity;
        this.listener = listener;
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) {
            BluetoothDevice d = result.getDevice();
            String name = "";
            if (result.getScanRecord() != null && result.getScanRecord().getDeviceName() != null)
                name = result.getScanRecord().getDeviceName();
            if (name.isEmpty()) try { name = d.getName(); } catch (SecurityException ignored) {}
            if (name != null && name.toLowerCase().startsWith("polar h10")) {
                final String address = d.getAddress();
                if (seen.add(address)) {
                    candidates.add(d);
                    candidatesLabels.add(name + " · " + address);
                    listener.update(0, "Found " + candidates.size() + " Polar H10 strap(s)…");
                }
            }
        }
        @Override public void onScanFailed(int code) {
            scanning = false;
            listener.update(0, "Bluetooth scan failed (" + code + ")");
        }
    };

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt target, int status, int state) {
            if (status != BluetoothGatt.GATT_SUCCESS || state == BluetoothProfile.STATE_DISCONNECTED) {
                listener.update(0, "Disconnected");
                closeGatt(target);
                return;
            }
            if (state == BluetoothProfile.STATE_CONNECTED) {
                listener.update(0, "Connected, enabling heart rate");
                if (hasBluetoothPermission()) try { target.discoverServices(); } catch (SecurityException ignored) {}
            }
        }
        @Override public void onServicesDiscovered(BluetoothGatt target, int status) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                listener.update(0, "Heart rate services unavailable"); return;
            }
            BluetoothGattService service = target.getService(HEART_SERVICE);
            BluetoothGattCharacteristic measurement = service == null ? null : service.getCharacteristic(HEART_MEASUREMENT);
            if (measurement == null) { listener.update(0, "Heart rate service not found"); return; }
            if (!hasBluetoothPermission()) return;
            try {
                target.setCharacteristicNotification(measurement, true);
                BluetoothGattDescriptor descriptor = measurement.getDescriptor(NOTIFY_DESCRIPTOR);
                if (descriptor != null) {
                    if (Build.VERSION.SDK_INT >= 33) target.writeDescriptor(descriptor, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                    else { descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE); target.writeDescriptor(descriptor); }
                }
                listener.update(0, "Waiting for heart rate data");
            } catch (SecurityException error) { listener.update(0, "Bluetooth permission missing"); }
        }
        @Override public void onCharacteristicChanged(BluetoothGatt target, BluetoothGattCharacteristic characteristic) {
            parseHeartRate(characteristic.getValue());
        }
        @Override public void onCharacteristicChanged(BluetoothGatt target, BluetoothGattCharacteristic characteristic, byte[] value) {
            parseHeartRate(value);
        }
    };

    public void start() {
        stop();
        candidates.clear();
        candidatesLabels.clear();
        seen.clear();
        BluetoothManager manager = (BluetoothManager) activity.getSystemService(Context.BLUETOOTH_SERVICE);
        BluetoothAdapter adapter = manager == null ? null : manager.getAdapter();
        if (adapter == null) { listener.update(0, "Bluetooth not available"); return; }
        if (!adapter.isEnabled()) { listener.update(0, "Turn on Bluetooth to connect"); return; }
        if (!hasBluetoothPermission()) { listener.update(0, "Bluetooth permission missing"); return; }
        try {
            scanner = adapter.getBluetoothLeScanner();
            if (scanner == null) { listener.update(0, "Bluetooth scanner unavailable"); return; }
            scanning = true;
            listener.update(0, "Searching for Polar H10…");
            scanner.startScan(scanCallback);
            handler.postDelayed(() -> {
                if (scanning) {
                    stopScanning();
                    if (candidates.isEmpty()) listener.update(0, "No Polar H10 found. Check that it's worn and nearby.");
                    else if (candidates.size() == 1) connect(candidates.get(0));
                    else new AlertDialog.Builder(activity)
                        .setTitle("Choose your Polar H10")
                        .setItems(candidatesLabels.toArray(new String[0]), (dialog, index) -> connect(candidates.get(index)))
                        .setNegativeButton("Cancel", (dialog, which) -> listener.update(0, "Not connected"))
                        .show();
                }
            }, 15000);
        } catch (SecurityException error) { listener.update(0, "Bluetooth access denied"); }
    }

    private void connect(BluetoothDevice d) {
        listener.update(0, "Connecting to " + d.getAddress());
        try { gatt = d.connectGatt(activity, false, gattCallback); }
        catch (SecurityException error) { listener.update(0, "Bluetooth permission unavailable"); }
    }

    public void stop() {
        stopScanning();
        if (gatt != null) closeGatt(gatt);
        listener.update(0, "Disconnected");
    }

    private void stopScanning() {
        if (!scanning) return;
        scanning = false;
        try { if (scanner != null && hasBluetoothPermission()) scanner.stopScan(scanCallback); }
        catch (SecurityException ignored) {}
    }

    private void closeGatt(BluetoothGatt target) {
        if (gatt == target) gatt = null;
        try { if (hasBluetoothPermission()) target.disconnect(); } catch (SecurityException ignored) {}
        target.close();
    }

    private boolean hasBluetoothPermission() {
        return Build.VERSION.SDK_INT < 31 ||
            activity.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    private void parseHeartRate(byte[] value) {
        if (value == null || value.length < 2) return;
        int flags = value[0] & 0xff;
        int bpm;
        if ((flags & 1) == 0) bpm = value[1] & 0xff;
        else if (value.length >= 3) bpm = (value[1] & 0xff) | ((value[2] & 0xff) << 8);
        else return;
        if (bpm > 25 && bpm < 240) listener.update(bpm, "Connected · Polar H10");
    }
}
