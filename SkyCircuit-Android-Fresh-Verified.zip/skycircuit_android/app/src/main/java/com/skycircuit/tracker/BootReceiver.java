package com.skycircuit.tracker;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Restore weekly notification alarms on reboot and clock/timezone changes. */
public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String action = intent == null ? "" : intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(action) ||
            Intent.ACTION_TIME_CHANGED.equals(action) ||
            Intent.ACTION_TIMEZONE_CHANGED.equals(action)) {
            ReminderScheduler.scheduleAll(context);
        }
    }
}
