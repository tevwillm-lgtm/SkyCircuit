package com.skycircuit.tracker;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

/** Native notification delivery even when the workout interface is not running. */
public class ReminderReceiver extends BroadcastReceiver {
    private static final String CHANNEL = "skycircuit_workouts";
    @Override public void onReceive(Context context, Intent intent) {
        int day = intent.getIntExtra("day", 0);
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) {
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel channel = new NotificationChannel(CHANNEL, "Workout reminders", NotificationManager.IMPORTANCE_DEFAULT);
                channel.setDescription("Notifications on your selected SkyCircuit training days");
                manager.createNotificationChannel(channel);
            }
            if (Build.VERSION.SDK_INT < 33 || context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                Intent open = new Intent(context, MainActivity.class);
                open.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                PendingIntent tap = PendingIntent.getActivity(context, 2001, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                Notification note = new Notification.Builder(context, CHANNEL)
                    .setSmallIcon(R.drawable.ic_notification)
                    .setContentTitle("SkyCircuit: today's workout")
                    .setContentText("Time to train. Open your Upper → Lower → Total rotation.")
                    .setContentIntent(tap)
                    .setAutoCancel(true)
                    .build();
                manager.notify(930 + day, note);
            }
        }
        // Android alarms are one-shot; reschedule this weekday for the following week.
        if (day >= 1 && day <= 7) ReminderScheduler.scheduleDay(context, day);
    }
}
