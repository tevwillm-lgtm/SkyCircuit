package com.skycircuit.tracker;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.OutputStream;

/** Offline-first native Android shell. Only app-bundled HTML is permitted inside WebView. */
public class MainActivity extends Activity {
    private static final int PICK_FILE = 412;
    private static final int CREATE_FILE = 413;
    private static final int NOTIFICATION_PERMISSION = 414;
    private static final int BLUETOOTH_PERMISSION = 415;
    private WebView webView;
    private HeartRateMonitor heartRateMonitor;
    private ValueCallback<Uri[]> uploadCallback;
    private byte[] pendingExport;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(16, 27, 26));
        getWindow().setNavigationBarColor(Color.rgb(16, 27, 26));
        heartRateMonitor = new HeartRateMonitor(this, (bpm, status) -> {
            if (webView != null) runOnUiThread(() -> webView.evaluateJavascript(
                "window.skyCircuitHrUpdate && window.skyCircuitHrUpdate(" + bpm + "," + org.json.JSONObject.quote(status) + ")", null));
        });
        webView = new WebView(this);
        webView.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        setContentView(webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowFileAccessFromFileURLs(false);
        webView.getSettings().setAllowUniversalAccessFromFileURLs(false);
        webView.getSettings().setBuiltInZoomControls(false);
        webView.getSettings().setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                // Never navigate to external content within a privileged local WebView.
                if (!"file".equalsIgnoreCase(uri.getScheme())) {
                    launchExternal(uri.toString());
                    return true;
                }
                return !uri.toString().startsWith("file:///android_asset/");
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view,
                    ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (uploadCallback != null) uploadCallback.onReceiveValue(null);
                uploadCallback = callback;
                try {
                    Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivityForResult(Intent.createChooser(intent, "Choose SkyCircuit file"), PICK_FILE);
                } catch (ActivityNotFoundException error) {
                    uploadCallback = null;
                    callback.onReceiveValue(null);
                    toast("No file picker found");
                }
                return true;
            }
        });
        webView.addJavascriptInterface(new NativeBridge(), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
    }

    public final class NativeBridge {
        @JavascriptInterface public void scheduleReminders(boolean enabled, int daysPerWeek, String time) {
            runOnUiThread(() -> {
                ReminderScheduler.configure(MainActivity.this, enabled, daysPerWeek, time);
                if (enabled) requestNotificationPermission();
            });
        }

        @JavascriptInterface public void startHeartRate() {
            runOnUiThread(MainActivity.this::startHeartRate);
        }
        @JavascriptInterface public void stopHeartRate() {
            runOnUiThread(() -> heartRateMonitor.stop());
        }

        @JavascriptInterface public void openExternal(String url) {
            runOnUiThread(() -> launchExternal(url));
        }

        @JavascriptInterface public void saveFile(String filename, String mime, String base64) {
            runOnUiThread(() -> {
                try {
                    if (base64.length() > 20_000_000) throw new IllegalArgumentException("Backup too large");
                    pendingExport = Base64.decode(base64, Base64.DEFAULT);
                    String sanitized = filename.replaceAll("[^a-zA-Z0-9_.-]", "_");
                    Intent save = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    save.addCategory(Intent.CATEGORY_OPENABLE);
                    save.setType(mime.equals("text/csv") ? "text/csv" : "application/json");
                    save.putExtra(Intent.EXTRA_TITLE, sanitized);
                    startActivityForResult(save, CREATE_FILE);
                } catch (Exception e) {
                    pendingExport = null;
                    toast("Could not prepare backup: " + e.getMessage());
                }
            });
        }
    }

    private void launchExternal(String url) {
        try {
            Uri uri = Uri.parse(url);
            if (!"https".equalsIgnoreCase(uri.getScheme())) return;
            Intent open = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(open);
        } catch (Exception error) {
            toast("No browser available to open the link");
        }
    }

    private void startHeartRate() {
        if (Build.VERSION.SDK_INT >= 31) {
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED ||
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}, BLUETOOTH_PERMISSION);
                return;
            }
        } else if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, BLUETOOTH_PERMISSION);
            return;
        }
        heartRateMonitor.start();
    }

    @Override public void onRequestPermissionsResult(int request, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(request, permissions, results);
        if (request == BLUETOOTH_PERMISSION) {
            boolean granted = results.length > 0;
            for (int result : results) if (result != PackageManager.PERMISSION_GRANTED) granted = false;
            if (granted) heartRateMonitor.start();
            else toast("Bluetooth permission needed to connect an H10 strap");
        }
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION);
        }
    }

    @Override @SuppressWarnings("deprecation") protected void onActivityResult(int code, int result, Intent intent) {
        super.onActivityResult(code, result, intent);
        if (code == PICK_FILE) {
            if (uploadCallback != null) {
                Uri uri = result == RESULT_OK && intent != null ? intent.getData() : null;
                uploadCallback.onReceiveValue(uri == null ? null : new Uri[]{uri});
                uploadCallback = null;
            }
        } else if (code == CREATE_FILE) {
            if (result == RESULT_OK && intent != null && intent.getData() != null && pendingExport != null) {
                try (OutputStream out = getContentResolver().openOutputStream(intent.getData())) {
                    if (out == null) throw new IllegalStateException("File unavailable");
                    out.write(pendingExport);
                    out.flush();
                    toast("File saved");
                } catch (Exception e) {
                    toast("File export failed: " + e.getMessage());
                }
            }
            pendingExport = null;
        }
    }

    @Override public void onBackPressed() {
        webView.evaluateJavascript("window.skyCircuitBack ? window.skyCircuitBack() : false", result -> {
            if ("false".equals(result)) finish();
        });
    }

    @Override protected void onDestroy() {
        if (heartRateMonitor != null) heartRateMonitor.stop();
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidBridge");
            webView.destroy();
        }
        super.onDestroy();
    }

    private void toast(String text) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
    }
}
