const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync(require('path').join(__dirname,'../app/src/main/assets/index.html'),'utf8').match(/<script>([\s\S]*)<\/script>/)[1];
const els=new Map(),listeners={};let notice='';
let app={innerHTML:''};els.set('#app',app);
const doc={querySelector:q=>els.get(q)||null,addEventListener:(name,cb)=>listeners[name]=cb,
createElement:(tag)=>({className:'',textContent:'',remove(){},click(){},setAttribute(){},innerHTML:'',style:{}}),body:{appendChild(x){if(x.className==='toast')notice=x.textContent},removeChild(){}},getElementById:()=>null};
const store=new Map();const c={document:doc,window:{open() {},scrollTo(){},setInterval(){},clearInterval(){}},
localStorage:{getItem:key=>store.get(key)||null,setItem:(key,value)=>store.set(key,value)},
location:{protocol:'file:'},navigator:{vibrate(){}},console,Date,Math,JSON,Number,String,Object,Array,Set,FormData:()=>{},
setTimeout:()=>1,clearTimeout(){},setInterval:()=>1,clearInterval(){},confirm:()=>true,URL,Blob};
vm.createContext(c);vm.runInContext(src,c,{timeout:1500});
function click(action,p={}){listeners.click({preventDefault(){},target:{closest(sel){return {dataset:{action,...p}}}}})}
assert(app.innerHTML.includes('Upper Body'));
click('nav',{tab:'settings'});assert(app.innerHTML.includes('Workout reminders'));
click('freq',{value:'5'});assert.equal(JSON.parse(store.get('skycircuit_v1')).frequency,5);
click('nav',{tab:'plans'});assert(app.innerHTML.includes('Form tips')===false);
click('start',{type:'A'});assert(app.innerHTML.includes('LIVE SESSION'));assert(app.innerHTML.includes('Form tips'));
click('toggle',{key:'1_a1'});assert.equal(JSON.parse(store.get('skycircuit_v1')).active.entries['1_a1'].done,true);
click('finish');let d=JSON.parse(store.get('skycircuit_v1'));assert.equal(d.history.length,1);assert(d.history[0].entries['1_a1'].done);
click('nav',{tab:'progress'});assert(app.innerHTML.includes('Polar workout imports'));assert(app.innerHTML.includes('Bodyweight'));
console.log('Passed core UI state smoke test (home/settings/5-day scheduling/logging/progress)');
