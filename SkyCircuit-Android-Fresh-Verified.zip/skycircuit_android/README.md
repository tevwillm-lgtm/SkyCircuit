# SkyCircuit — Android Workout Tracker

An offline-first Android app for a three-workout rotation based on the user's Big Sky–style training: **Upper Body → Lower Body → Total Body → repeat**, 3–5 days per week.

## What is included

- Offline workout tracking, including 2 or 3 circuit rounds, set checkoffs, load and repetition entry, remembered working weights, and resumable in-progress workouts.
- Customizable upper/lower/full-body exercise libraries, concise form guidance, and links to external exercise-video searches (internet required for video).
- Workout timer, rest timer, session notes, rate-of-perceived-exertion (RPE), complete-set and volume history, and six-week frequency chart.
- Adjustable 3, 4, or 5-day weekly goal; the next focus is determined by the most recently **finished** workout.
- Native Android workout-day notifications at your chosen time. These are **inexact alarms** and Android may delay them for battery optimization.
- On-device Polar H10 **live Bluetooth heart rate**, while the app remains open. Wear the strap and tap **Connect H10** during a workout. A selector appears if multiple H10 devices are found. Recorded heart-rate samples contribute to session average and peak HR. This integration is implemented but **not tested on a physical H10** in the current build environment.
- Import of **Polar Flow TCX and CSV files**, showing whatever calories, duration and heart-rate fields can be extracted. CSV export structures vary. There is **no automatic Polar Flow account sync**.
- Weight entries and optional goal weight; local-only data, JSON backup/import, CSV session export.

## Build an Android APK with Android Studio

**Prerequisites:** recent Android Studio, Java 17, Android SDK Platform 35, internet access for initial Gradle/plugin download.

1. Extract this ZIP on your computer.
2. Open **Android Studio → Open**, then select the extracted `skycircuit_android` folder.
3. If Android Studio asks to configure a Gradle distribution, use **Gradle 8.9** and allow the project to sync. The repository does not contain a downloaded Gradle wrapper JAR or Android SDK.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Find `app/build/outputs/apk/debug/app-debug.apk` and transfer it to your Android phone.
6. On the phone, open the APK and explicitly allow installation from the selected file source if Android asks. Then launch **SkyCircuit**, set reminder permissions, and begin training.

Alternatively, build directly with Gradle 8.9 (if already installed):

```bash
gradle assembleDebug
```

The result is a debug-signed APK for personal testing. For production distribution, generate a release signing key and signed release build using Android Studio.

## Generate APK with GitHub Actions (no local Android Studio)

1. Create a **private** GitHub repository and upload the **contents** of this folder into the repository root (preserving `.github/workflows/build-apk.yml`). Do not upload workout data/backups.
2. In GitHub, choose **Actions → Build SkyCircuit Android APK → Run workflow** (or push to main).
3. After the job succeeds, open the run's **Artifacts** section and download `SkyCircuit-debug-apk`.
4. Extract the artifact ZIP, transfer the `app-debug.apk` to your Android phone, and install it.

The workflow installs Java 17, Android SDK 35, Gradle 8.9, compiles the source, and uploads the resulting APK artifact. Debug APK signing is automatically performed by Android's Gradle plugin.

## Permissions and privacy

- Notifications: sends workout reminders on chosen days.
- Bluetooth scan/connect: user-initiated Polar H10 live heart rate. Android 11 and earlier may also require location permission *for Bluetooth scanning*; SkyCircuit never accesses GPS/location coordinates.
- Boot completion: restores the reminder alarms after a reboot.
- Files: uses Android's system file picker / save dialog; no broad storage permission.

Workout data stays in Android WebView storage on the local device. No remote account, analytics, or backend is configured. Data will be lost when app data is wiped or the app is uninstalled **unless exported**.

## Technical structure

- Java Android host: `app/src/main/java/com/skycircuit/tracker`
- Offline app frontend: `app/src/main/assets/index.html`
- Android permissions + entry point: `app/src/main/AndroidManifest.xml`
- APK build workflow: `.github/workflows/build-apk.yml`
- Package ID: `com.skycircuit.tracker`; minimum Android 8 (API 26), target API 35.

## Caveats

- Android APK compilation, hardware Bluetooth pairing, and notification delivery **could not be verified here** because Android SDK / Gradle tools and a physical Android device were unavailable. The source and web-state behavior were checked locally, but build on Android Studio or GitHub Actions before describing the result as an installed Android app.
- This is a personal training tool, not a medical device or source of precise calorie expenditure.
- No automatic cloud backup, Polar Flow OAuth, meal logging, curated offline exercise videos, or Google Play Store listing.
- A clean install does not automatically inherit records from the prior browser app. Export JSON from the browser app, then use SkyCircuit's **Import backup** to migrate.
